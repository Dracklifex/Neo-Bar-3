package com.neobar.statusbar

import android.content.Context
import android.content.SharedPreferences

/** Configuración visual de la barra. */
data class Config(
    val bg1: Int,
    val bg2: Int,
    val gradient: Boolean,
    val opacity: Int,      // 0..100
    val text: Int,
    val content: Boolean,  // dibujar reloj/fecha/batería propios
    val clock: Boolean,
    val h24: Boolean,
    val date: Boolean,
    val battery: Boolean,
    val align: Int,        // 0 = reloj izquierda, 1 = centro, 2 = derecha
    val size: Int,         // tamaño del texto
    val corner: Int        // radio de esquinas inferiores en dp
)

class Preset(
    val name: String,
    val bg1: Int,
    val bg2: Int,
    val gradient: Boolean,
    val text: Int,
    val opacity: Int
)

object Prefs {
    const val ENABLED = "enabled"
    const val BG1 = "bg1"
    const val BG2 = "bg2"
    const val GRADIENT = "gradient"
    const val OPACITY = "opacity"
    const val TEXT = "text"
    const val CONTENT = "content"
    const val CLOCK = "clock"
    const val H24 = "h24"
    const val DATE = "date"
    const val BATTERY = "battery"
    const val ALIGN = "align"
    const val SIZE = "size"
    const val CORNER = "corner"

    val DEF_BG1: Int = 0xFF101018.toInt()
    val DEF_BG2: Int = 0xFFE5173F.toInt()
    val DEF_TEXT: Int = 0xFFFFFFFF.toInt()

    val presets = listOf(
        Preset("Noche", 0xFF101018.toInt(), 0xFF101018.toInt(), false, 0xFFFFFFFF.toInt(), 100),
        Preset("RedMagic", 0xFF1A0006.toInt(), 0xFFE5173F.toInt(), true, 0xFFFFFFFF.toInt(), 100),
        Preset("Neón", 0xFF0A0F1F.toInt(), 0xFF00E5FF.toInt(), true, 0xFFE8FFFF.toInt(), 100),
        Preset("Atardecer", 0xFF3A1C71.toInt(), 0xFFFFAF7B.toInt(), true, 0xFFFFFFFF.toInt(), 100),
        Preset("Bosque", 0xFF0B2E13.toInt(), 0xFF2ECC71.toInt(), true, 0xFFFFFFFF.toInt(), 100),
        Preset("Claro", 0xFFF4F4F8.toInt(), 0xFFF4F4F8.toInt(), false, 0xFF111111.toInt(), 100)
    )

    fun sp(c: Context): SharedPreferences =
        c.getSharedPreferences("neobar", Context.MODE_PRIVATE)

    fun config(sp: SharedPreferences) = Config(
        bg1 = sp.getInt(BG1, DEF_BG1),
        bg2 = sp.getInt(BG2, DEF_BG2),
        gradient = sp.getBoolean(GRADIENT, false),
        opacity = sp.getInt(OPACITY, 100),
        text = sp.getInt(TEXT, DEF_TEXT),
        content = sp.getBoolean(CONTENT, false),
        clock = sp.getBoolean(CLOCK, true),
        h24 = sp.getBoolean(H24, true),
        date = sp.getBoolean(DATE, false),
        battery = sp.getBoolean(BATTERY, true),
        align = sp.getInt(ALIGN, 0),
        size = sp.getInt(SIZE, 13),
        corner = sp.getInt(CORNER, 0)
    )
}
