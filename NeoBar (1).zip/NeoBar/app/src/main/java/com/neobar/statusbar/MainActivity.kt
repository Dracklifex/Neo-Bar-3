package com.neobar.statusbar

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.IntentFilter
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private lateinit var sp: SharedPreferences
    private lateinit var preview: BarView
    private lateinit var master: Switch
    private val refreshers = mutableListOf<() -> Unit>()
    private var syncing = false

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        sp = Prefs.sp(this)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(24), dp(16), dp(40))
        }
        val scroll = ScrollView(this).apply {
            setBackgroundColor(0xFF0B0B10.toInt())
            addView(root)
        }
        setContentView(scroll)

        root.addView(heading("NeoBar"))
        root.addView(note("Barra de estado personalizada para tu Nubia Neo 3"))

        // Vista previa
        val frame = FrameLayout(this).apply { setBackgroundColor(0xFF555566.toInt()) }
        preview = BarView(this).apply { this.preview = true }
        frame.addView(
            preview,
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(28))
        )
        root.addView(
            frame,
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(64)).apply {
                topMargin = dp(12)
                bottomMargin = dp(8)
            }
        )

        master = Switch(this).apply {
            text = "Activar barra"
            setTextColor(Color.WHITE)
            textSize = 18f
            setPadding(0, dp(8), 0, dp(8))
        }
        master.setOnCheckedChangeListener { _, checked ->
            if (!syncing) onMaster(checked)
        }
        root.addView(master)

        root.addView(header("TEMAS RÁPIDOS"))
        root.addView(presetRow())

        root.addView(header("COLORES"))
        root.addView(colorRow("Fondo", Prefs.BG1, Prefs.DEF_BG1))
        root.addView(toggle("Degradado horizontal", Prefs.GRADIENT, false))
        root.addView(colorRow("Color final del degradado", Prefs.BG2, Prefs.DEF_BG2))
        root.addView(colorRow("Texto e iconos", Prefs.TEXT, Prefs.DEF_TEXT))

        root.addView(header("FORMA"))
        root.addView(slider("Opacidad", Prefs.OPACITY, 0, 100, 100, "%"))
        root.addView(slider("Esquinas redondeadas", Prefs.CORNER, 0, 16, 0, " dp"))

        root.addView(header("FONDO"))
        root.addView(
            radios(
                "Textura incluida",
                Prefs.PATTERN,
                listOf("Sin textura", "Rayas diagonales", "Puntos", "Rejilla", "Carbono"),
                0
            )
        )
        root.addView(imageControls())
        root.addView(slider("Posición vertical de la imagen", Prefs.IMG_Y, 0, 100, 50, "%"))
        root.addView(slider("Oscurecer imagen", Prefs.DIM, 0, 90, 0, "%"))

        root.addView(header("CONTENIDO"))
        root.addView(toggle("Dibujar reloj, fecha y batería propios (se encima a los iconos del sistema)", Prefs.CONTENT, false))
        root.addView(toggle("Mostrar reloj", Prefs.CLOCK, true))
        root.addView(toggle("Formato 24 horas", Prefs.H24, true))
        root.addView(toggle("Mostrar fecha", Prefs.DATE, false))
        root.addView(toggle("Mostrar batería", Prefs.BATTERY, true))
        root.addView(slider("Tamaño del texto", Prefs.SIZE, 9, 20, 13, " sp"))
        root.addView(alignGroup())

        root.addView(header("NOTAS"))
        root.addView(
            note(
                "• Android dibuja la barra del sistema por encima de las ventanas de otras apps. " +
                    "Por eso NeoBar tiñe el fondo y los iconos reales de señal, wifi, reloj y batería " +
                    "se siguen viendo encima.\n" +
                    "• Los iconos del sistema conservan su propio color (claro u oscuro). Con un fondo " +
                    "claro pueden no leerse bien: prueba un tema oscuro o baja la opacidad.\n" +
                    "• Si activas el reloj y la batería propios, se verán encimados con los del sistema.\n" +
                    "• Si el sistema cierra la app, permite ejecución en segundo plano en Ajustes > Batería.\n" +
                    "• La imagen de fondo se copia a la memoria privada de la app y no pide permiso de archivos. " +
                    "Se recorta al ancho de la barra sin deformarse: usa \"Posición vertical\" para elegir qué franja se ve.\n" +
                    "• Usa \"Desactivar\" en la notificación para quitar la barra rápido."
            )
        )
    }

    override fun onResume() {
        super.onResume()
        val on = sp.getBoolean(Prefs.ENABLED, false) && Settings.canDrawOverlays(this)
        setMaster(on)
        refreshers.forEach { it() }
        refreshPreview()
        registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
            ?.let { preview.applyBatteryIntent(it) }
        if (on) startForegroundService(Intent(this, OverlayService::class.java))
    }

    private fun setMaster(v: Boolean) {
        syncing = true
        master.isChecked = v
        syncing = false
    }

    private fun onMaster(on: Boolean) {
        if (on) {
            if (!Settings.canDrawOverlays(this)) {
                Toast.makeText(
                    this,
                    "Concede \"Mostrar sobre otras apps\" y vuelve a activar",
                    Toast.LENGTH_LONG
                ).show()
                startActivity(
                    Intent(
                        Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:$packageName")
                    )
                )
                setMaster(false)
                return
            }
            if (Build.VERSION.SDK_INT >= 33 &&
                checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) !=
                PackageManager.PERMISSION_GRANTED
            ) {
                requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
            }
            sp.edit().putBoolean(Prefs.ENABLED, true).apply()
            startForegroundService(Intent(this, OverlayService::class.java))
        } else {
            sp.edit().putBoolean(Prefs.ENABLED, false).apply()
            stopService(Intent(this, OverlayService::class.java))
        }
    }

    private fun refreshPreview() {
        preview.cfg = Prefs.config(sp)
    }

    // ---------- Componentes de UI ----------

    private fun heading(t: String) = TextView(this).apply {
        text = t
        setTextColor(Color.WHITE)
        textSize = 28f
        typeface = Typeface.DEFAULT_BOLD
    }

    private fun note(t: String) = TextView(this).apply {
        text = t
        setTextColor(0xFFB0B0C0.toInt())
        textSize = 13f
        setPadding(0, dp(4), 0, dp(4))
    }

    private fun header(t: String) = TextView(this).apply {
        text = t
        setTextColor(0xFFFF3B5C.toInt())
        textSize = 13f
        typeface = Typeface.DEFAULT_BOLD
        setPadding(0, dp(22), 0, dp(6))
    }

    private fun presetRow(): View {
        val scroller = HorizontalScrollView(this)
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        Prefs.presets.forEach { p ->
            val b = Button(this).apply {
                text = p.name
                isAllCaps = false
                setOnClickListener {
                    sp.edit()
                        .putInt(Prefs.BG1, p.bg1)
                        .putInt(Prefs.BG2, p.bg2)
                        .putBoolean(Prefs.GRADIENT, p.gradient)
                        .putInt(Prefs.TEXT, p.text)
                        .putInt(Prefs.OPACITY, p.opacity)
                        .apply()
                    refreshers.forEach { it() }
                    refreshPreview()
                }
            }
            row.addView(b)
        }
        scroller.addView(row)
        return scroller
    }

    private fun toggle(label: String, key: String, def: Boolean): View {
        val s = Switch(this).apply {
            text = label
            setTextColor(Color.WHITE)
            setPadding(0, dp(8), 0, dp(8))
        }
        fun load() {
            syncing = true
            s.isChecked = sp.getBoolean(key, def)
            syncing = false
        }
        load()
        refreshers.add { load() }
        s.setOnCheckedChangeListener { _, c ->
            if (!syncing) {
                sp.edit().putBoolean(key, c).apply()
                refreshPreview()
            }
        }
        return s
    }

    private fun slider(label: String, key: String, lo: Int, hi: Int, def: Int, suffix: String): View {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, dp(6), 0, dp(6))
        }
        val tv = TextView(this).apply { setTextColor(Color.WHITE) }
        val sb = SeekBar(this).apply { max = hi - lo }
        fun show(v: Int) {
            tv.text = "$label: $v$suffix"
        }
        fun load() {
            val v = sp.getInt(key, def)
            sb.progress = v - lo
            show(v)
        }
        load()
        refreshers.add { load() }
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                if (!fromUser) return
                val v = p + lo
                sp.edit().putInt(key, v).apply()
                show(v)
                refreshPreview()
            }

            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        box.addView(tv)
        box.addView(sb)
        return box
    }

    private fun colorRow(label: String, key: String, def: Int): View {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, dp(8), 0, dp(8))
        }
        val head = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val swatch = View(this)
        val tv = TextView(this).apply {
            text = label
            setTextColor(Color.WHITE)
            setPadding(dp(10), 0, 0, 0)
        }
        head.addView(swatch, LinearLayout.LayoutParams(dp(28), dp(28)))
        head.addView(tv)
        box.addView(head)

        val tints = intArrayOf(0xFFFF5252.toInt(), 0xFF69F0AE.toInt(), 0xFF40C4FF.toInt())
        val bars = Array(3) { i ->
            SeekBar(this).apply {
                max = 255
                progressTintList = ColorStateList.valueOf(tints[i])
                thumbTintList = ColorStateList.valueOf(tints[i])
            }
        }
        fun load() {
            val c = sp.getInt(key, def)
            bars[0].progress = Color.red(c)
            bars[1].progress = Color.green(c)
            bars[2].progress = Color.blue(c)
            swatch.setBackgroundColor(c)
        }
        load()
        refreshers.add { load() }
        val listener = object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                if (!fromUser) return
                val c = Color.rgb(bars[0].progress, bars[1].progress, bars[2].progress)
                sp.edit().putInt(key, c).apply()
                swatch.setBackgroundColor(c)
                refreshPreview()
            }

            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        }
        bars.forEach {
            it.setOnSeekBarChangeListener(listener)
            box.addView(it)
        }
        return box
    }

    companion object {
        private const val REQ_IMAGE = 41
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != REQ_IMAGE || resultCode != RESULT_OK) return
        val uri = data?.data ?: return
        Toast.makeText(this, "Procesando imagen…", Toast.LENGTH_SHORT).show()
        Thread {
            val ok = Images.saveFrom(this, uri)
            runOnUiThread {
                if (ok) {
                    sp.edit()
                        .putBoolean(Prefs.IMAGE, true)
                        .putLong(Prefs.IMG_VER, System.currentTimeMillis())
                        .apply()
                    refreshers.forEach { it() }
                    refreshPreview()
                } else {
                    Toast.makeText(this, "No se pudo leer esa imagen", Toast.LENGTH_LONG).show()
                }
            }
        }.start()
    }

    private fun imageControls(): View {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, dp(6), 0, dp(6))
        }
        val status = TextView(this).apply {
            setTextColor(0xFFB0B0C0.toInt())
            textSize = 13f
        }
        fun load() {
            status.text = if (sp.getBoolean(Prefs.IMAGE, false)) {
                "Imagen de fondo activa"
            } else {
                "Sin imagen de fondo"
            }
        }
        load()
        refreshers.add { load() }

        val pick = Button(this).apply {
            text = "Elegir imagen"
            isAllCaps = false
        }
        pick.setOnClickListener {
            val i = Intent(Intent.ACTION_OPEN_DOCUMENT)
            i.addCategory(Intent.CATEGORY_OPENABLE)
            i.type = "image/*"
            try {
                startActivityForResult(i, REQ_IMAGE)
            } catch (e: Exception) {
                Toast.makeText(this, "No se pudo abrir el selector de imágenes", Toast.LENGTH_LONG).show()
            }
        }

        val clear = Button(this).apply {
            text = "Quitar imagen"
            isAllCaps = false
        }
        clear.setOnClickListener {
            Images.clear(this)
            sp.edit()
                .putBoolean(Prefs.IMAGE, false)
                .putLong(Prefs.IMG_VER, System.currentTimeMillis())
                .apply()
            refreshers.forEach { it() }
            refreshPreview()
        }

        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        row.addView(pick)
        row.addView(clear)
        box.addView(status)
        box.addView(row)
        return box
    }

    private fun radios(title: String, key: String, names: List<String>, def: Int): View {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, dp(6), 0, dp(6))
        }
        val label = TextView(this).apply {
            text = title
            setTextColor(Color.WHITE)
        }
        box.addView(label)
        val group = RadioGroup(this)
        group.orientation = RadioGroup.VERTICAL
        val ids = names.map { View.generateViewId() }
        names.forEachIndexed { i, n ->
            val rb = RadioButton(this)
            rb.id = ids[i]
            rb.text = n
            rb.setTextColor(Color.WHITE)
            group.addView(rb)
        }
        fun load() {
            syncing = true
            group.check(ids[sp.getInt(key, def).coerceIn(0, names.size - 1)])
            syncing = false
        }
        load()
        refreshers.add { load() }
        group.setOnCheckedChangeListener { _, checkedId ->
            if (!syncing) {
                sp.edit().putInt(key, ids.indexOf(checkedId)).apply()
                refreshPreview()
            }
        }
        box.addView(group)
        return box
    }

    private fun alignGroup(): View {
        val group = RadioGroup(this).apply { orientation = RadioGroup.VERTICAL }
        val names = listOf(
            "Reloj a la izquierda",
            "Reloj al centro (puede chocar con la cámara)",
            "Reloj a la derecha"
        )
        val ids = names.map { View.generateViewId() }
        names.forEachIndexed { i, n ->
            val rb = RadioButton(this).apply {
                id = ids[i]
                text = n
                setTextColor(Color.WHITE)
            }
            group.addView(rb)
        }
        fun load() {
            syncing = true
            group.check(ids[sp.getInt(Prefs.ALIGN, 0).coerceIn(0, 2)])
            syncing = false
        }
        load()
        refreshers.add { load() }
        group.setOnCheckedChangeListener { _, checkedId ->
            if (!syncing) {
                sp.edit().putInt(Prefs.ALIGN, ids.indexOf(checkedId)).apply()
                refreshPreview()
            }
        }
        return group
    }
}
