package com.neobar.statusbar

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.os.BatteryManager
import android.view.View
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Vista que dibuja la barra personalizada (se usa en el overlay y en la vista previa). */
class BarView(context: Context) : View(context) {

    private val bg = Paint(Paint.ANTI_ALIAS_FLAG)
    private val tp = Paint(Paint.ANTI_ALIAS_FLAG)
    private val outline = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()
    private val imgPaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val dimPaint = Paint()
    private val pat = Paint(Paint.ANTI_ALIAS_FLAG)
    private val srcRect = Rect()
    private val dstRect = RectF()
    private var bmp: Bitmap? = null
    private var bmpVer = -1L
    private val d = resources.displayMetrics.density

    var cfg: Config = Prefs.config(Prefs.sp(context))
        set(value) {
            field = value
            invalidate()
        }

    /** En la vista previa de la app se dibujan iconos de muestra aunque el contenido propio esté apagado. */
    var preview = false

    private var pct = 100
    private var charging = false

    fun setBattery(level: Int, isCharging: Boolean) {
        pct = level.coerceIn(0, 100)
        charging = isCharging
        invalidate()
    }

    private fun withAlpha(color: Int, a: Int): Int = (color and 0x00FFFFFF) or (a shl 24)

    /** Carga la imagen de fondo solo cuando cambia. */
    private fun ensureBitmap() {
        val want = if (cfg.image) cfg.imageVer else 0L
        if (want == bmpVer) return
        bmpVer = want
        bmp = if (cfg.image) Images.load(context) else null
    }

    /** Dibuja la imagen recortada al tamaño de la barra, sin deformarla. */
    private fun drawImage(canvas: Canvas, w: Float, h: Float, alpha: Int) {
        val b = bmp ?: return
        if (w <= 0f || h <= 0f) return
        val barAspect = w / h
        val imgAspect = b.width.toFloat() / b.height.toFloat()
        val sw: Int
        val sh: Int
        if (imgAspect > barAspect) {
            sh = b.height
            sw = (b.height * barAspect).toInt().coerceIn(1, b.width)
        } else {
            sw = b.width
            sh = (b.width / barAspect).toInt().coerceIn(1, b.height)
        }
        val left = (b.width - sw) / 2
        val top = ((b.height - sh) * cfg.imgY.coerceIn(0, 100) / 100f).toInt()
        srcRect.set(left, top, left + sw, top + sh)
        dstRect.set(0f, 0f, w, h)
        imgPaint.alpha = alpha
        canvas.drawBitmap(b, srcRect, dstRect, imgPaint)
        if (cfg.dim > 0) {
            val dimAlpha = cfg.dim.coerceIn(0, 90) * 255 / 100 * alpha / 255
            dimPaint.color = dimAlpha shl 24
            canvas.drawRect(0f, 0f, w, h, dimPaint)
        }
    }

    /** Texturas incluidas: se dibujan con el color del texto, muy suaves. */
    private fun drawPattern(canvas: Canvas, w: Float, h: Float) {
        pat.color = withAlpha(cfg.text, 40)
        pat.strokeWidth = 1f * d
        val step = 6f * d
        when (cfg.pattern) {
            1 -> {
                var x = -h
                while (x < w) {
                    canvas.drawLine(x, h, x + h, 0f, pat)
                    x += step
                }
            }
            2 -> {
                var y = step / 2f
                while (y < h) {
                    var x = step / 2f
                    while (x < w) {
                        canvas.drawCircle(x, y, 0.9f * d, pat)
                        x += step
                    }
                    y += step
                }
            }
            3 -> {
                var x = 0f
                while (x < w) {
                    canvas.drawLine(x, 0f, x, h, pat)
                    x += step * 2f
                }
                var y = 0f
                while (y < h) {
                    canvas.drawLine(0f, y, w, y, pat)
                    y += step * 2f
                }
            }
            4 -> {
                val s = 3f * d
                var row = 0
                var y = 0f
                while (y < h) {
                    var col = 0
                    var x = 0f
                    while (x < w) {
                        if ((row + col) % 2 == 0) canvas.drawRect(x, y, x + s, y + s, pat)
                        x += s
                        col++
                    }
                    y += s
                    row++
                }
            }
        }
    }

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        ensureBitmap()

        // Fondo: color o degradado, imagen y textura, todo recortado a la forma de la barra
        val a = cfg.opacity.coerceIn(0, 100) * 255 / 100
        val c1 = withAlpha(cfg.bg1, a)
        val c2 = withAlpha(cfg.bg2, a)
        bg.shader = if (cfg.gradient) {
            LinearGradient(0f, 0f, w, 0f, c1, c2, Shader.TileMode.CLAMP)
        } else {
            null
        }
        bg.color = c1
        val r = cfg.corner * d
        path.reset()
        path.addRoundRect(
            0f, 0f, w, h,
            floatArrayOf(0f, 0f, 0f, 0f, r, r, r, r),
            Path.Direction.CW
        )
        canvas.save()
        canvas.clipPath(path)
        canvas.drawPath(path, bg)
        drawImage(canvas, w, h, a)
        if (cfg.pattern != 0) drawPattern(canvas, w, h)
        canvas.restore()

        if (!cfg.content && !preview) return

        // Texto
        tp.color = cfg.text
        tp.textSize = cfg.size * d
        tp.typeface = Typeface.DEFAULT_BOLD
        val baseline = h / 2f - (tp.ascent() + tp.descent()) / 2f
        val pad = 18f * d
        val gap = 10f * d
        val now = Date()
        val clockS = if (cfg.clock) {
            SimpleDateFormat(if (cfg.h24) "HH:mm" else "h:mm a", Locale.getDefault()).format(now)
        } else ""
        val dateS = if (cfg.date) {
            SimpleDateFormat("EEE d MMM", Locale.getDefault()).format(now)
        } else ""
        val batW = if (cfg.battery) batteryWidth() else 0f

        when (cfg.align) {
            0 -> {
                var x = pad
                if (clockS.isNotEmpty()) {
                    canvas.drawText(clockS, x, baseline, tp)
                    x += tp.measureText(clockS) + gap
                }
                if (dateS.isNotEmpty()) canvas.drawText(dateS, x, baseline, tp)
                if (cfg.battery) drawBattery(canvas, w - pad - batW, h / 2f)
            }
            1 -> {
                if (dateS.isNotEmpty()) canvas.drawText(dateS, pad, baseline, tp)
                if (clockS.isNotEmpty()) {
                    canvas.drawText(clockS, (w - tp.measureText(clockS)) / 2f, baseline, tp)
                }
                if (cfg.battery) drawBattery(canvas, w - pad - batW, h / 2f)
            }
            else -> {
                var x = pad
                if (cfg.battery) {
                    drawBattery(canvas, x, h / 2f)
                    x += batW + gap
                }
                if (dateS.isNotEmpty()) canvas.drawText(dateS, x, baseline, tp)
                if (clockS.isNotEmpty()) {
                    canvas.drawText(clockS, w - pad - tp.measureText(clockS), baseline, tp)
                }
            }
        }
    }

    private fun batteryText() = "$pct%"

    private fun batteryWidth(): Float = 20f * d + 6f * d + tp.measureText(batteryText())

    private fun drawBattery(canvas: Canvas, x: Float, cy: Float) {
        val bw = 20f * d
        val bh = 10f * d
        val top = cy - bh / 2f

        outline.color = cfg.text
        outline.strokeWidth = 1.2f * d
        canvas.drawRoundRect(x, top, x + bw, top + bh, 2f * d, 2f * d, outline)

        // Borne de la batería
        fill.color = cfg.text
        canvas.drawRect(x + bw, cy - 2.5f * d, x + bw + 1.8f * d, cy + 2.5f * d, fill)

        // Nivel
        fill.color = when {
            charging -> 0xFF4CD964.toInt()
            pct <= 15 -> 0xFFFF3B30.toInt()
            else -> cfg.text
        }
        val inset = 2f * d
        val levelRight = x + inset + (bw - 2f * inset) * pct / 100f
        canvas.drawRect(x + inset, top + inset, levelRight, top + bh - inset, fill)

        // Porcentaje
        canvas.drawText(batteryText(), x + bw + 6f * d, cy - (tp.ascent() + tp.descent()) / 2f, tp)
    }
}

/** Lee un Intent de ACTION_BATTERY_CHANGED y actualiza la vista. */
fun BarView.applyBatteryIntent(intent: Intent) {
    val level = intent.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
    val scale = intent.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
    val status = intent.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
    val charging = status == BatteryManager.BATTERY_STATUS_CHARGING ||
        status == BatteryManager.BATTERY_STATUS_FULL
    if (level >= 0 && scale > 0) setBattery(level * 100 / scale, charging)
}
