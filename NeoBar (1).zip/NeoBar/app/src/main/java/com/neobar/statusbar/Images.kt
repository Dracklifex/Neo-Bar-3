package com.neobar.statusbar

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.media.ExifInterface
import android.net.Uri
import java.io.File
import java.io.FileOutputStream

/** Guarda la imagen de fondo elegida en la carpeta privada de la app. */
object Images {
    private const val FILE = "bar_bg.png"
    private const val MAX_SIDE = 1600

    private fun target(context: Context): File = File(context.filesDir, FILE)

    /** Copia la imagen elegida, reducida y con la rotación corregida. Devuelve true si salió bien. */
    fun saveFrom(context: Context, uri: Uri): Boolean {
        try {
            val resolver = context.contentResolver

            val bounds = BitmapFactory.Options()
            bounds.inJustDecodeBounds = true
            resolver.openInputStream(uri).use { BitmapFactory.decodeStream(it, null, bounds) }
            if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return false

            var sample = 1
            while (bounds.outWidth / (sample * 2) >= MAX_SIDE || bounds.outHeight / (sample * 2) >= MAX_SIDE) {
                sample *= 2
            }
            val opts = BitmapFactory.Options()
            opts.inSampleSize = sample
            val decoded = resolver.openInputStream(uri).use { BitmapFactory.decodeStream(it, null, opts) }
                ?: return false

            var orientation = ExifInterface.ORIENTATION_NORMAL
            try {
                resolver.openInputStream(uri).use { stream ->
                    if (stream != null) {
                        orientation = ExifInterface(stream).getAttributeInt(
                            ExifInterface.TAG_ORIENTATION,
                            ExifInterface.ORIENTATION_NORMAL
                        )
                    }
                }
            } catch (e: Exception) {
                // sin datos de rotación
            }
            val degrees = when (orientation) {
                ExifInterface.ORIENTATION_ROTATE_90 -> 90f
                ExifInterface.ORIENTATION_ROTATE_180 -> 180f
                ExifInterface.ORIENTATION_ROTATE_270 -> 270f
                else -> 0f
            }

            var bmp: Bitmap = decoded
            if (degrees != 0f) {
                val m = Matrix()
                m.postRotate(degrees)
                bmp = Bitmap.createBitmap(decoded, 0, 0, decoded.width, decoded.height, m, true)
            }

            val longest = maxOf(bmp.width, bmp.height)
            if (longest > MAX_SIDE) {
                val scale = MAX_SIDE.toFloat() / longest.toFloat()
                val nw = maxOf(1, (bmp.width * scale).toInt())
                val nh = maxOf(1, (bmp.height * scale).toInt())
                bmp = Bitmap.createScaledBitmap(bmp, nw, nh, true)
            }

            FileOutputStream(target(context)).use { out ->
                bmp.compress(Bitmap.CompressFormat.PNG, 100, out)
            }
            return true
        } catch (e: Exception) {
            return false
        }
    }

    fun load(context: Context): Bitmap? {
        val f = target(context)
        if (!f.exists()) return null
        return try {
            BitmapFactory.decodeFile(f.absolutePath)
        } catch (e: Exception) {
            null
        }
    }

    fun clear(context: Context) {
        target(context).delete()
    }
}
