# NeoBar

Tiñe la barra de estado de Android (pensada para el Nubia Neo 3) con temas, colores,
degradado, esquinas redondeadas, imagen de fondo y texturas, con vista previa en vivo.

Android dibuja la barra del sistema por encima de las ventanas de otras apps, así que
NeoBar pone una ventana de color debajo y los iconos reales (señal, wifi, reloj, batería)
se siguen viendo encima. Opcionalmente dibuja su propio reloj, fecha y batería, que se
encima a los del sistema.

## Fondo
- **Imagen de fondo:** elige una foto o imagen de tu galería. Se copia a la memoria privada
  de la app (no pide permiso de archivos), se reduce a 1600 px y se recorta al ancho de la
  barra sin deformarla. "Posición vertical" decide qué franja de la imagen se ve y
  "Oscurecer imagen" ayuda a que los iconos del sistema se lean. Los PNG con transparencia
  se respetan.
- **Texturas incluidas:** rayas diagonales, puntos, rejilla y carbono, dibujadas con el color
  del texto.

## Compilar el APK desde el teléfono (GitHub)
1. En el navegador abre github.com/new y crea un repositorio (modo "Sitio de escritorio" del navegador).
2. Add file > Upload files, elige el zip (sin descomprimir) y confirma el commit.
3. Add file > Create new file, nombre `.github/workflows/build.yml`, pega el contenido de
   `NeoBar/.github/workflows/build.yml` tal cual y confirma el commit.
   El texto funciona aunque el editor pierda los espacios al pegar.
4. En la pestaña Actions espera a que termine "Build APK" (unos 3 a 5 minutos).
5. En Releases > `latest` descarga `NeoBar.apk` e instálalo.

Para actualizar la app: borra el zip anterior del repositorio (abre el archivo, menú de tres
puntos, Delete file) y sube el nuevo. Si quedan dos zips, la compilación puede usar el viejo.

## Compilar en Android Studio
Abre esta carpeta, deja que Gradle sincronice y elige Build > Build APK(s).

## Uso
Abre NeoBar, activa el interruptor y concede "Mostrar sobre otras apps".

## Límites
- Los iconos del sistema conservan su color; con fondos claros o imágenes claras pueden no
  leerse. Usa "Oscurecer imagen" o un fondo oscuro.
- El arranque automático depende de que Nubia no lo bloquee.
- Es un APK de depuración y no se ha probado en un teléfono.
