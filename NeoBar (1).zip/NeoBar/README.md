# NeoBar

Tiñe la barra de estado de Android (pensada para el Nubia Neo 3) con temas, colores,
degradado y esquinas redondeadas, con vista previa en vivo.

Android dibuja la barra del sistema por encima de las ventanas de otras apps, así que
NeoBar pone una ventana de color debajo y los iconos reales (señal, wifi, reloj, batería)
se siguen viendo encima. Opcionalmente dibuja su propio reloj, fecha y batería, que se
encima a los del sistema.

## Compilar el APK desde el teléfono (GitHub)
1. En el navegador abre github.com/new y crea un repositorio (modo "Sitio de escritorio" del navegador).
2. Add file > Upload files, elige `NeoBar.zip` (sin descomprimir) y confirma el commit.
3. Add file > Create new file, nombre `.github/workflows/build.yml`, pega el contenido de
   `NeoBar/.github/workflows/build.yml` y confirma el commit.
4. En la pestaña Actions espera a que termine "Build APK" (unos 3 a 5 minutos).
5. En Releases > `latest` descarga `NeoBar.apk` e instálalo.

## Compilar en Android Studio
Abre esta carpeta, deja que Gradle sincronice y elige Build > Build APK(s).

## Uso
Abre NeoBar, activa el interruptor y concede "Mostrar sobre otras apps".

## Límites
- Los iconos del sistema conservan su color; con fondos claros pueden no leerse.
- El arranque automático depende de que Nubia no lo bloquee.
- Es un APK de depuración y no se ha probado en un teléfono.
